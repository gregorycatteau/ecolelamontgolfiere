// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Mentions Legales\",\"_path\":\"/mentions-legales\"},{\"title\":\"essai\",\"_path\":\"/peda\"},{\"title\":\"PROJET PEDAGOGIQUE\",\"_path\":\"/projetpedagogique\"},{\"title\":\"Projetpedagogique2\",\"_path\":\"/projetpedagogique2\"},{\"title\":\"Statuts Asso Lamontgolfiere\",\"_path\":\"/statuts-asso-lamontgolfiere\"},{\"title\":\"StatutsAssociatifs\",\"_path\":\"/statuts_associatifs\"}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
