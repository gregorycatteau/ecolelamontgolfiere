// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/mentions-legales\":[\"content:mentions-legales.md\"],\"/peda\":[\"content:peda.md\"],\"/projetpedagogique\":[\"content:projetpedagogique.md\"],\"/projetpedagogique2\":[\"content:projetpedagogique2.md\"],\"/statuts-asso-lamontgolfiere\":[\"content:statuts asso lamontgolfiere.md\"],\"/statuts_associatifs\":[\"content:statuts_associatifs.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
