// ROLLUP_NO_REPLACE 
 const peda = "{\"parsed\":{\"_path\":\"/peda\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"_empty\":false,\"title\":\"essai\",\"description\":\"voici un essai\\nlink\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"essai\"},\"children\":[{\"type\":\"text\",\"value\":\"essai\"}]},{\"type\":\"element\",\"tag\":\"p\",\"props\":{},\"children\":[{\"type\":\"text\",\"value\":\"voici un essai\\n\"},{\"type\":\"element\",\"tag\":\"a\",\"props\":{\"href\":\"join\"},\"children\":[{\"type\":\"text\",\"value\":\"link\"}]}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:peda.md\",\"_source\":\"content\",\"_file\":\"peda.md\",\"_extension\":\"md\"},\"hash\":\"zbxVqHzW0E\"}";

export { peda as default };
//# sourceMappingURL=peda.mjs.map
