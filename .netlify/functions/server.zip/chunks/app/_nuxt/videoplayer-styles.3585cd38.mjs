const videoplayer_vue_vue_type_style_index_0_scoped_8d604a89_lang = ".wrapper[data-v-8d604a89]{--tw-bg-opacity:1;align-items:center;background-color:#c7d2fe;background-color:rgb(199 210 254/var(--tw-bg-opacity));border-radius:1.5rem;display:flex;gap:2.5rem;justify-content:space-between;margin:2.5rem auto;padding:2.5rem;position:relative;width:91.666667%}.title[data-v-8d604a89]{--tw-text-opacity:1;color:#3730a3;color:rgb(55 48 163/var(--tw-text-opacity));font-size:1.875rem;font-weight:700;line-height:2.25rem;margin-bottom:2rem}";

const videoplayerStyles_3585cd38 = [videoplayer_vue_vue_type_style_index_0_scoped_8d604a89_lang];

export { videoplayerStyles_3585cd38 as default };
//# sourceMappingURL=videoplayer-styles.3585cd38.mjs.map
