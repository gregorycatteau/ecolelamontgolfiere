const rejoindre_vue_vue_type_style_index_0_scoped_3ef07159_lang = ".title[data-v-3ef07159]{font-size:2.25rem;font-weight:700;line-height:2.5rem;margin-bottom:2.5rem;margin-top:2.5rem;text-align:center}.wrapper[data-v-3ef07159]{width:100%}.subwrapper[data-v-3ef07159],.wrapper[data-v-3ef07159]{align-items:center;display:flex;flex-direction:column;justify-content:center;margin:2.5rem auto;padding:2.5rem}.subwrapper[data-v-3ef07159]{width:75%}.text[data-v-3ef07159]{font-size:1.125rem;line-height:1.75rem}.reasons[data-v-3ef07159],.text[data-v-3ef07159]{font-weight:700;margin-bottom:2.5rem;margin-top:2.5rem;text-align:center}.reasons[data-v-3ef07159]{font-size:1.5rem;line-height:2rem}.olstyle[data-v-3ef07159]{list-style-position:inside;list-style-type:decimal}.listyle[data-v-3ef07159]{font-size:1.125rem;font-weight:700;line-height:1.75rem;text-align:justify;text-indent:2.5rem}";

const rejoindreStyles_c0b432fa = [rejoindre_vue_vue_type_style_index_0_scoped_3ef07159_lang];

export { rejoindreStyles_c0b432fa as default };
//# sourceMappingURL=rejoindre-styles.c0b432fa.mjs.map
