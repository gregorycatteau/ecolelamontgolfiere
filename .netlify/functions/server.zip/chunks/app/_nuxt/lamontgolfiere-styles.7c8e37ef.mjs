const lamontgolfiere_vue_vue_type_style_index_0_scoped_fd3725c0_lang = ".title[data-v-fd3725c0]{--tw-text-opacity:1;color:#374151;color:rgb(55 65 81/var(--tw-text-opacity));font-size:2.25rem;font-weight:700;line-height:2.5rem;text-align:center}";

const lamontgolfiereStyles_7c8e37ef = [lamontgolfiere_vue_vue_type_style_index_0_scoped_fd3725c0_lang];

export { lamontgolfiereStyles_7c8e37ef as default };
//# sourceMappingURL=lamontgolfiere-styles.7c8e37ef.mjs.map
