const ecole_vue_vue_type_style_index_0_scoped_2de4cde6_lang = ".wrapperingall[data-v-2de4cde6]{--tw-bg-opacity:1;background-color:#fff;background-color:rgb(255 255 255/var(--tw-bg-opacity));background-position:50%;background-repeat:no-repeat;background-size:cover;height:100%;width:100%}.wrapperimg[data-v-2de4cde6]{--tw-aspect-w:16;padding-bottom:calc(var(--tw-aspect-h)/var(--tw-aspect-w)*100%);position:relative}.wrapperimg>*[data-v-2de4cde6]{bottom:0;height:100%;left:0;position:absolute;right:0;top:0;width:100%}.wrapperimg[data-v-2de4cde6]{--tw-aspect-h:9;margin:auto;width:91.666667%}.imagefond[data-v-2de4cde6]{border-bottom-left-radius:9999px;border-bottom-right-radius:9999px;height:auto;margin-top:2.5rem;max-width:100%;-o-object-fit:cover;object-fit:cover;z-index:10}.suite[data-v-2de4cde6]{margin-top:20rem}";

const ecoleStyles_1299787f = [ecole_vue_vue_type_style_index_0_scoped_2de4cde6_lang];

export { ecoleStyles_1299787f as default };
//# sourceMappingURL=ecole-styles.1299787f.mjs.map
