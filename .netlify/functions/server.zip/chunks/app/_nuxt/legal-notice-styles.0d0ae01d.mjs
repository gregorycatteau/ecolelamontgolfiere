const legalNotice_vue_vue_type_style_index_0_scoped_1d509193_lang = ".title[data-v-1d509193]{--tw-text-opacity:1;color:#374151;color:rgb(55 65 81/var(--tw-text-opacity));font-size:2.25rem;font-weight:700;line-height:2.5rem;text-align:center}";

const legalNoticeStyles_0d0ae01d = [legalNotice_vue_vue_type_style_index_0_scoped_1d509193_lang];

export { legalNoticeStyles_0d0ae01d as default };
//# sourceMappingURL=legal-notice-styles.0d0ae01d.mjs.map
