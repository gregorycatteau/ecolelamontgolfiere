const inscription_vue_vue_type_style_index_0_scoped_4675caf9_lang = ".wrapper[data-v-4675caf9]{margin-bottom:2.5rem;position:relative}.imagefond[data-v-4675caf9]{border-radius:1.5rem;margin:auto;width:91.666667%}.postitle[data-v-4675caf9]{align-items:flex-start;display:flex;height:100%;justify-content:center;left:0;position:absolute;top:15rem;width:100%}.overlay[data-v-4675caf9]{--tw-bg-opacity:0.5;background-color:hsla(0,0%,100%,.5);background-color:rgb(255 255 255/var(--tw-bg-opacity));border-radius:.5rem;padding:2rem;text-align:center}.title[data-v-4675caf9]{font-size:4.5rem;margin-bottom:2rem}.subtitle[data-v-4675caf9],.title[data-v-4675caf9]{--tw-text-opacity:1;color:#3730a3;color:rgb(55 48 163/var(--tw-text-opacity));font-weight:700;line-height:1}.subtitle[data-v-4675caf9]{font-size:3rem}";

const inscriptionStyles_263e4553 = [inscription_vue_vue_type_style_index_0_scoped_4675caf9_lang];

export { inscriptionStyles_263e4553 as default };
//# sourceMappingURL=inscription-styles.263e4553.mjs.map
