const Icon_vue_vue_type_style_index_0_scoped_cf1ec82f_lang = ".icon[data-v-cf1ec82f]{display:inline-block;vertical-align:middle}";

const IconStyles_95b220bc = [Icon_vue_vue_type_style_index_0_scoped_cf1ec82f_lang];

export { IconStyles_95b220bc as default };
//# sourceMappingURL=Icon-styles.95b220bc.mjs.map
