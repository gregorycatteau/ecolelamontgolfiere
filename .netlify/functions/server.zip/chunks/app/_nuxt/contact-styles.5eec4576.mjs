const contact_vue_vue_type_style_index_0_scoped_e8cae118_lang = ".wrapper[data-v-e8cae118]{margin:2.5rem;padding:2.5rem}.maintitle[data-v-e8cae118]{font-size:3.75rem;line-height:1}.maintitle[data-v-e8cae118],.title[data-v-e8cae118]{--tw-text-opacity:1;color:#374151;color:rgb(55 65 81/var(--tw-text-opacity));font-weight:700;margin:2.5rem;padding:2.5rem;text-align:center}.title[data-v-e8cae118]{font-size:2.25rem;line-height:2.5rem}@media (min-width:640px){.columns[data-v-e8cae118]{display:flex;flex-direction:row;margin:auto;width:91.666667%}.column1[data-v-e8cae118]{padding-left:1.25rem;padding-right:1.25rem;width:66.666667%}}@media (min-width:768px){.column1[data-v-e8cae118]{width:50%}}@media (min-width:640px){.column2[data-v-e8cae118]{padding-left:1.25rem;padding-right:1.25rem;width:33.333333%}}@media (min-width:768px){.column2[data-v-e8cae118]{width:50%}}";

const contactStyles_5eec4576 = [contact_vue_vue_type_style_index_0_scoped_e8cae118_lang];

export { contactStyles_5eec4576 as default };
//# sourceMappingURL=contact-styles.5eec4576.mjs.map
