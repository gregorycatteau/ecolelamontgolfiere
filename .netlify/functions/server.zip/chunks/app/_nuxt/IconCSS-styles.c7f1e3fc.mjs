const IconCSS_vue_vue_type_style_index_0_scoped_11604bcf_lang = "span[data-v-11604bcf]{background-color:currentColor;display:inline-block;-webkit-mask-image:var(--71ded496);mask-image:var(--71ded496);-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% 100%;mask-size:100% 100%;vertical-align:middle}";

const IconCSSStyles_c7f1e3fc = [IconCSS_vue_vue_type_style_index_0_scoped_11604bcf_lang];

export { IconCSSStyles_c7f1e3fc as default };
//# sourceMappingURL=IconCSS-styles.c7f1e3fc.mjs.map
