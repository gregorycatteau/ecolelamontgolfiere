const default_vue_vue_type_style_index_0_scoped_d6b1c5c8_lang = ".extwrapper[data-v-d6b1c5c8]{display:flex;flex-direction:column;min-height:100vh}.intwrapper[data-v-d6b1c5c8]{flex:1 1 0%}";

const defaultStyles_ab2f2659 = [default_vue_vue_type_style_index_0_scoped_d6b1c5c8_lang];

export { defaultStyles_ab2f2659 as default };
//# sourceMappingURL=default-styles.ab2f2659.mjs.map
