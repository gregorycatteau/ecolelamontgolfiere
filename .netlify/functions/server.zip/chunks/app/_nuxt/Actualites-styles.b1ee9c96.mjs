const Actualites_vue_vue_type_style_index_0_scoped_f20b8537_lang = ".title[data-v-f20b8537]{--tw-text-opacity:1;color:#374151;color:rgb(55 65 81/var(--tw-text-opacity));font-size:2.25rem;font-weight:700;line-height:2.5rem;text-align:center}";

const ActualitesStyles_b1ee9c96 = [Actualites_vue_vue_type_style_index_0_scoped_f20b8537_lang];

export { ActualitesStyles_b1ee9c96 as default };
//# sourceMappingURL=Actualites-styles.b1ee9c96.mjs.map
