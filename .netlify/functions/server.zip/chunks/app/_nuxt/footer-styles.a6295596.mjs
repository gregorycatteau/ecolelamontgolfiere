const footer_vue_vue_type_style_index_0_scoped_3d8076ff_lang = ".footing[data-v-3d8076ff]{background-color:#c7d2fe;background-color:rgb(199 210 254/var(--tw-bg-opacity))}.dark[data-v-3d8076ff],.footing[data-v-3d8076ff]{--tw-bg-opacity:1}.dark[data-v-3d8076ff]{--tw-text-opacity:1;background-color:#1f2937;background-color:rgb(31 41 55/var(--tw-bg-opacity));color:#f3f4f6;color:rgb(243 244 246/var(--tw-text-opacity))}.nav[data-v-3d8076ff]{align-items:center;justify-content:space-between;padding:1rem 1.5rem}.nav[data-v-3d8076ff],.ul[data-v-3d8076ff]{display:flex}.ul[data-v-3d8076ff]{list-style-type:none;margin:0;padding:0}.li[data-v-3d8076ff]{margin-right:1.5rem}";

const footerStyles_a6295596 = [footer_vue_vue_type_style_index_0_scoped_3d8076ff_lang];

export { footerStyles_a6295596 as default };
//# sourceMappingURL=footer-styles.a6295596.mjs.map
