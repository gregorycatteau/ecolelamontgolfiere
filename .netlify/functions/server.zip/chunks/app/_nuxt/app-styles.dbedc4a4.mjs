const app_vue_vue_type_style_index_0_lang = ".page-enter-active,.page-leave-active{transition:all .4s}.page-enter-from,.page-leave-to{filter:blur(1rem);opacity:0}";

const appStyles_dbedc4a4 = [app_vue_vue_type_style_index_0_lang];

export { appStyles_dbedc4a4 as default };
//# sourceMappingURL=app-styles.dbedc4a4.mjs.map
