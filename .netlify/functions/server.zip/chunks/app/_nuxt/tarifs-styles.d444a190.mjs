const tarifs_vue_vue_type_style_index_0_scoped_2e207629_lang = ".title[data-v-2e207629]{--tw-text-opacity:1;color:#374151;color:rgb(55 65 81/var(--tw-text-opacity));font-size:2.25rem;font-weight:700;line-height:2.5rem;text-align:center}";

const tarifsStyles_d444a190 = [tarifs_vue_vue_type_style_index_0_scoped_2e207629_lang];

export { tarifsStyles_d444a190 as default };
//# sourceMappingURL=tarifs-styles.d444a190.mjs.map
